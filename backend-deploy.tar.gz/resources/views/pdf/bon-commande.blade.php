<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Bon de Commande - {{ $order->reference }}</title>
    <style>
        @font-face {
            font-family: 'DejaVu Sans';
            src: url('{{ storage_path("fonts/DejaVuSans.ttf") }}') format('truetype');
        }
        * {
            font-family: 'DejaVu Sans', sans-serif;
        }
        body {
            direction: rtl;
            text-align: right;
            font-size: 12px;
            line-height: 1.6;
            color: #333;
        }
        .header {
            text-align: center;
            border-bottom: 2px solid #333;
            padding-bottom: 15px;
            margin-bottom: 20px;
        }
        .header h1 {
            font-size: 24px;
            margin: 0;
            color: #1a56db;
        }
        .header p {
            margin: 5px 0;
            color: #666;
        }
        .info-section {
            display: table;
            width: 100%;
            margin-bottom: 20px;
        }
        .info-box {
            display: table-cell;
            width: 48%;
            vertical-align: top;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .info-box h3 {
            margin: 0 0 10px 0;
            padding-bottom: 5px;
            border-bottom: 1px solid #eee;
            color: #1a56db;
            font-size: 14px;
        }
        .info-box p {
            margin: 3px 0;
        }
        .info-label {
            color: #666;
            font-size: 11px;
        }
        .reference-box {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
        }
        .reference-box .ref {
            font-size: 20px;
            font-weight: bold;
            color: #1a56db;
        }
        .reference-box .date {
            color: #666;
            font-size: 12px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th {
            background: #1a56db;
            color: white;
            padding: 10px 8px;
            text-align: right;
            font-weight: bold;
        }
        td {
            padding: 10px 8px;
            border-bottom: 1px solid #eee;
        }
        tr:nth-child(even) {
            background: #f9fafb;
        }
        .text-center {
            text-align: center;
        }
        .text-left {
            text-align: left;
        }
        .totals {
            width: 300px;
            margin-right: auto;
            margin-left: 0;
        }
        .totals td {
            padding: 8px;
        }
        .totals .label {
            text-align: right;
            color: #666;
        }
        .totals .value {
            text-align: left;
            font-weight: bold;
        }
        .totals .grand-total {
            background: #1a56db;
            color: white;
        }
        .totals .grand-total td {
            font-size: 16px;
        }
        .footer {
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
        }
        .signatures {
            display: table;
            width: 100%;
            margin-top: 30px;
        }
        .signature-box {
            display: table-cell;
            width: 45%;
            text-align: center;
            padding: 20px;
        }
        .signature-line {
            border-top: 1px solid #333;
            margin-top: 50px;
            padding-top: 5px;
        }
        .notes {
            background: #fffbeb;
            border: 1px solid #fbbf24;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .notes h4 {
            margin: 0 0 5px 0;
            color: #92400e;
        }
        .status-badge {
            display: inline-block;
            padding: 3px 10px;
            border-radius: 15px;
            font-size: 11px;
            font-weight: bold;
        }
        .status-pending { background: #fef3c7; color: #92400e; }
        .status-confirmed { background: #dbeafe; color: #1e40af; }
        .status-delivered { background: #d1fae5; color: #065f46; }
        .barcode {
            text-align: center;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>{{ config('app.name', 'شركتي') }}</h1>
        <p>بسكرة، الجزائر</p>
        <p>هاتف: 0555123456</p>
    </div>

    <div class="reference-box">
        <div class="ref">سند الطلب: {{ $order->reference }}</div>
        <div class="date">التاريخ: {{ \Carbon\Carbon::parse($order->date)->format('Y-m-d') }}</div>
        <span class="status-badge status-{{ $order->status }}">
            @switch($order->status)
                @case('pending') معلق @break
                @case('confirmed') مؤكد @break
                @case('assigned') موزع @break
                @case('delivered') تم التسليم @break
                @case('partial') تسليم جزئي @break
                @case('cancelled') ملغي @break
                @default {{ $order->status }}
            @endswitch
        </span>
    </div>

    <div class="info-section">
        <div class="info-box" style="margin-left: 2%;">
            <h3>معلومات العميل</h3>
            <p><strong>{{ $order->client->name ?? '-' }}</strong></p>
            <p><span class="info-label">الهاتف:</span> {{ $order->client->phone ?? '-' }}</p>
            <p><span class="info-label">العنوان:</span> {{ $order->client->address ?? '-' }}</p>
        </div>
        <div class="info-box" style="margin-right: 2%;">
            <h3>معلومات الطلب</h3>
            <p><span class="info-label">المستودع:</span> {{ $order->warehouse->name ?? '-' }}</p>
            <p><span class="info-label">البائع:</span> {{ $order->seller->name ?? '-' }}</p>
            @if($order->trip)
            <p><span class="info-label">الجولة:</span> {{ $order->trip->reference ?? '-' }}</p>
            @endif
        </div>
    </div>

    <table>
        <thead>
            <tr>
                <th style="width: 5%;">#</th>
                <th style="width: 35%;">المنتج</th>
                <th style="width: 15%;" class="text-center">الكمية</th>
                <th style="width: 15%;" class="text-center">السعر</th>
                <th style="width: 10%;" class="text-center">الخصم</th>
                <th style="width: 20%;" class="text-left">المجموع</th>
            </tr>
        </thead>
        <tbody>
            @foreach($order->items as $index => $item)
            <tr>
                <td class="text-center">{{ $index + 1 }}</td>
                <td>
                    <strong>{{ $item->product->name ?? 'منتج محذوف' }}</strong>
                    @if($item->product && $item->product->barcode)
                    <br><small style="color: #666;">{{ $item->product->barcode }}</small>
                    @endif
                </td>
                <td class="text-center">{{ $item->quantity_confirmed ?? $item->quantity_ordered }}</td>
                <td class="text-center">{{ number_format($item->unit_price, 2) }}</td>
                <td class="text-center">{{ number_format($item->discount, 2) }}</td>
                <td class="text-left">{{ number_format($item->subtotal, 2) }} د.ج</td>
            </tr>
            @endforeach
        </tbody>
    </table>

    <table class="totals">
        <tr>
            <td class="label">المجموع الفرعي:</td>
            <td class="value">{{ number_format($order->total_amount, 2) }} د.ج</td>
        </tr>
        @if($order->discount > 0)
        <tr>
            <td class="label">الخصم:</td>
            <td class="value" style="color: #dc2626;">- {{ number_format($order->discount, 2) }} د.ج</td>
        </tr>
        @endif
        @if($order->tax > 0)
        <tr>
            <td class="label">الضريبة (TVA):</td>
            <td class="value">{{ number_format($order->tax, 2) }} د.ج</td>
        </tr>
        @endif
        <tr class="grand-total">
            <td class="label">المجموع الكلي:</td>
            <td class="value">{{ number_format($order->grand_total, 2) }} د.ج</td>
        </tr>
    </table>

    @if($order->notes)
    <div class="notes">
        <h4>ملاحظات:</h4>
        <p>{{ $order->notes }}</p>
    </div>
    @endif

    <div class="footer">
        <div class="signatures">
            <div class="signature-box">
                <div class="signature-line">توقيع العميل</div>
            </div>
            <div class="signature-box">
                <div class="signature-line">توقيع السائق</div>
            </div>
        </div>
    </div>

    <div class="barcode">
        <p style="font-family: monospace; font-size: 14px; letter-spacing: 3px;">{{ $order->reference }}</p>
    </div>

    <p style="text-align: center; color: #999; font-size: 10px; margin-top: 20px;">
        تم إنشاء هذا المستند بتاريخ {{ now()->format('Y-m-d H:i') }}
    </p>
</body>
</html>
