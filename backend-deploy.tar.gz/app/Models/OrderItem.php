<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OrderItem extends Model
{
    use HasFactory;

    protected $fillable = [
        'order_id',
        'product_id',
        'quantity_ordered',
        'quantity_confirmed',
        'quantity_delivered',
        'quantity_returned',
        'unit_price',
        'discount',
        'subtotal',
        'notes',
    ];

    protected $casts = [
        'quantity_ordered' => 'decimal:2',
        'quantity_confirmed' => 'decimal:2',
        'quantity_delivered' => 'decimal:2',
        'quantity_returned' => 'decimal:2',
        'unit_price' => 'decimal:2',
        'discount' => 'decimal:2',
        'subtotal' => 'decimal:2',
    ];

    protected static function boot()
    {
        parent::boot();

        static::creating(function ($model) {
            $model->subtotal = ($model->quantity_ordered * $model->unit_price) - $model->discount;
        });

        static::updating(function ($model) {
            $model->subtotal = ($model->quantity_ordered * $model->unit_price) - $model->discount;
        });
    }

    public function order()
    {
        return $this->belongsTo(Order::class);
    }

    public function product()
    {
        return $this->belongsTo(Product::class);
    }

    public function getPendingQuantity()
    {
        return $this->quantity_confirmed - $this->quantity_delivered - $this->quantity_returned;
    }
}
