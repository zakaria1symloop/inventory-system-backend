<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DeliveryReturn extends Model
{
    use HasFactory;

    protected $fillable = [
        'delivery_id',
        'order_id',
        'product_id',
        'quantity',
        'reason',
        'notes',
        'processed',
        'processed_at',
    ];

    protected $casts = [
        'quantity' => 'decimal:2',
        'processed' => 'boolean',
        'processed_at' => 'datetime',
    ];

    public function delivery()
    {
        return $this->belongsTo(Delivery::class);
    }

    public function order()
    {
        return $this->belongsTo(Order::class);
    }

    public function product()
    {
        return $this->belongsTo(Product::class);
    }

    public function process($warehouseId)
    {
        // Add stock back to warehouse and record movement
        StockMovement::record(
            $this->product_id,
            $warehouseId,
            $this->quantity,
            StockMovement::TYPE_DELIVERY_RETURN,
            $this->delivery->reference,
            $this->delivery,
            null,
            'مرتجع توصيل: ' . $this->getReasonLabel()
        );

        $orderItem = $this->order->items()->where('product_id', $this->product_id)->first();
        if ($orderItem) {
            $orderItem->quantity_returned += $this->quantity;
            $orderItem->save();
        }

        $this->processed = true;
        $this->processed_at = now();
        $this->save();
    }

    public function getReasonLabel()
    {
        $labels = [
            'refused' => 'مرفوض',
            'damaged' => 'تالف',
            'excess' => 'زيادة',
            'store_closed' => 'المحل مغلق',
            'other' => 'أخرى',
        ];

        return $labels[$this->reason] ?? $this->reason;
    }

    public function scopeUnprocessed($query)
    {
        return $query->where('processed', false);
    }

    public function scopeProcessed($query)
    {
        return $query->where('processed', true);
    }

    public function scopeByReason($query, $reason)
    {
        return $query->where('reason', $reason);
    }
}
