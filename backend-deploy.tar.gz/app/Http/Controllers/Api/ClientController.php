<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Client;
use Illuminate\Http\Request;

class ClientController extends Controller
{
    public function index(Request $request)
    {
        $query = Client::query();

        if ($request->active_only) {
            $query->active();
        }

        if ($request->search) {
            $query->where(function ($q) use ($request) {
                $q->where('name', 'like', "%{$request->search}%")
                  ->orWhere('phone', 'like', "%{$request->search}%")
                  ->orWhere('email', 'like', "%{$request->search}%");
            });
        }

        if ($request->has_balance) {
            $query->where('balance', '>', 0);
        }

        $clients = $query->latest()->paginate($request->per_page ?? 15);

        return response()->json($clients);
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'phone' => 'nullable|string',
            'email' => 'nullable|email',
            'address' => 'nullable|string',
            'gps_lat' => 'nullable|numeric',
            'gps_lng' => 'nullable|numeric',
            'credit_limit' => 'nullable|numeric|min:0',
            'is_active' => 'boolean',
        ]);

        $client = Client::create($request->all());

        return response()->json($client, 201);
    }

    public function show(Client $client)
    {
        return response()->json($client->load(['orders', 'sales']));
    }

    public function update(Request $request, Client $client)
    {
        $request->validate([
            'name' => 'string|max:255',
            'phone' => 'nullable|string',
            'email' => 'nullable|email',
            'address' => 'nullable|string',
            'gps_lat' => 'nullable|numeric',
            'gps_lng' => 'nullable|numeric',
            'credit_limit' => 'nullable|numeric|min:0',
            'is_active' => 'boolean',
        ]);

        $client->update($request->all());

        return response()->json($client);
    }

    public function destroy(Client $client)
    {
        $client->delete();

        return response()->json(['message' => 'تم حذف العميل بنجاح']);
    }

    public function getBalance(Client $client)
    {
        return response()->json([
            'balance' => $client->balance,
            'credit_limit' => $client->credit_limit,
            'available_credit' => $client->availableCredit(),
        ]);
    }

    public function getOrders(Client $client, Request $request)
    {
        $orders = $client->orders()
            ->with(['items.product', 'seller'])
            ->latest()
            ->paginate($request->per_page ?? 15);

        return response()->json($orders);
    }

    public function getSales(Client $client, Request $request)
    {
        $sales = $client->sales()
            ->with(['items.product', 'user'])
            ->latest()
            ->paginate($request->per_page ?? 15);

        return response()->json($sales);
    }
}
