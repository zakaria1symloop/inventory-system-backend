<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Supplier;
use Illuminate\Http\Request;

class SupplierController extends Controller
{
    public function index(Request $request)
    {
        $query = Supplier::query();

        if ($request->active_only) {
            $query->active();
        }

        if ($request->search) {
            $query->where(function ($q) use ($request) {
                $q->where('name', 'like', "%{$request->search}%")
                  ->orWhere('company_name', 'like', "%{$request->search}%")
                  ->orWhere('phone', 'like', "%{$request->search}%");
            });
        }

        if ($request->has_balance) {
            $query->where('balance', '>', 0);
        }

        $suppliers = $query->latest()->paginate($request->per_page ?? 15);

        return response()->json($suppliers);
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'phone' => 'nullable|string',
            'email' => 'nullable|email',
            'address' => 'nullable|string',
            'company_name' => 'nullable|string',
            'tax_number' => 'nullable|string',
            'is_active' => 'boolean',
        ]);

        $supplier = Supplier::create($request->all());

        return response()->json($supplier, 201);
    }

    public function show(Supplier $supplier)
    {
        return response()->json($supplier->load(['purchases', 'purchaseReturns']));
    }

    public function update(Request $request, Supplier $supplier)
    {
        $request->validate([
            'name' => 'string|max:255',
            'phone' => 'nullable|string',
            'email' => 'nullable|email',
            'address' => 'nullable|string',
            'company_name' => 'nullable|string',
            'tax_number' => 'nullable|string',
            'is_active' => 'boolean',
        ]);

        $supplier->update($request->all());

        return response()->json($supplier);
    }

    public function destroy(Supplier $supplier)
    {
        $supplier->delete();

        return response()->json(['message' => 'تم حذف المورد بنجاح']);
    }

    public function getBalance(Supplier $supplier)
    {
        return response()->json(['balance' => $supplier->balance]);
    }

    public function getPurchases(Supplier $supplier, Request $request)
    {
        $purchases = $supplier->purchases()
            ->with(['items.product', 'user', 'warehouse'])
            ->latest()
            ->paginate($request->per_page ?? 15);

        return response()->json($purchases);
    }
}
