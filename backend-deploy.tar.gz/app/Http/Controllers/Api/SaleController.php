<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Sale;
use App\Models\SaleItem;
use App\Models\SaleReturn;
use App\Models\SaleReturnItem;
use App\Models\Stock;
use App\Models\StockMovement;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SaleController extends Controller
{
    public function index(Request $request)
    {
        $query = Sale::with(['client', 'warehouse', 'user']);

        if ($request->client_id) {
            $query->where('client_id', $request->client_id);
        }

        if ($request->warehouse_id) {
            $query->where('warehouse_id', $request->warehouse_id);
        }

        if ($request->status) {
            $query->where('status', $request->status);
        }

        if ($request->payment_status) {
            $query->where('payment_status', $request->payment_status);
        }

        if ($request->from_date) {
            $query->whereDate('date', '>=', $request->from_date);
        }

        if ($request->to_date) {
            $query->whereDate('date', '<=', $request->to_date);
        }

        if ($request->search) {
            $query->where('reference', 'like', "%{$request->search}%");
        }

        $sales = $query->latest()->paginate($request->per_page ?? 15);

        return response()->json($sales);
    }

    public function store(Request $request)
    {
        $request->validate([
            'client_id' => 'nullable|exists:clients,id',
            'warehouse_id' => 'required|exists:warehouses,id',
            'date' => 'required|date',
            'discount' => 'nullable|numeric|min:0',
            'tax' => 'nullable|numeric|min:0',
            'shipping' => 'nullable|numeric|min:0',
            'note' => 'nullable|string',
            'items' => 'required|array|min:1',
            'items.*.product_id' => 'required|exists:products,id',
            'items.*.quantity' => 'required|numeric|min:0.01',
            'items.*.unit_price' => 'required|numeric|min:0',
            'items.*.discount' => 'nullable|numeric|min:0',
            'items.*.tax' => 'nullable|numeric|min:0',
        ]);

        DB::beginTransaction();

        try {
            // Validate stock availability for all items first (considering reserved quantities from orders)
            foreach ($request->items as $item) {
                $product = \App\Models\Product::find($item['product_id']);
                $productName = $product ? $product->name : 'غير معروف';

                // Use getAvailableStock to check stock minus reserved quantities
                $availableQty = Stock::getAvailableStock($item['product_id'], $request->warehouse_id);

                if ($availableQty < $item['quantity']) {
                    throw new \Exception("الكمية غير متوفرة للمنتج: {$productName}. المتوفر: {$availableQty}، المطلوب: {$item['quantity']}");
                }
            }

            $sale = Sale::create([
                'client_id' => $request->client_id,
                'warehouse_id' => $request->warehouse_id,
                'user_id' => auth()->id(),
                'date' => $request->date,
                'discount' => $request->discount ?? 0,
                'tax' => $request->tax ?? 0,
                'shipping' => $request->shipping ?? 0,
                'note' => $request->note,
                'status' => 'completed',
            ]);

            foreach ($request->items as $item) {
                SaleItem::create([
                    'sale_id' => $sale->id,
                    'product_id' => $item['product_id'],
                    'quantity' => $item['quantity'],
                    'unit_price' => $item['unit_price'],
                    'discount' => $item['discount'] ?? 0,
                    'tax' => $item['tax'] ?? 0,
                ]);

                // Record stock movement
                StockMovement::record(
                    $item['product_id'],
                    $request->warehouse_id,
                    $item['quantity'],
                    StockMovement::TYPE_SALE,
                    $sale->reference,
                    $sale,
                    $item['unit_price']
                );
            }

            $sale->calculateTotals();

            if ($request->client_id) {
                $sale->client->updateBalance($sale->grand_total, 'add');
            }

            DB::commit();

            return response()->json($sale->load(['client', 'warehouse', 'user', 'items.product']), 201);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['message' => $e->getMessage()], 500);
        }
    }

    public function show(Sale $sale)
    {
        return response()->json($sale->load(['client', 'warehouse', 'user', 'items.product', 'payments', 'returns']));
    }

    public function update(Request $request, Sale $sale)
    {
        $request->validate([
            'discount' => 'nullable|numeric|min:0',
            'tax' => 'nullable|numeric|min:0',
            'shipping' => 'nullable|numeric|min:0',
            'note' => 'nullable|string',
        ]);

        $sale->update($request->only(['discount', 'tax', 'shipping', 'note']));
        $sale->calculateTotals();

        return response()->json($sale->load(['client', 'warehouse', 'user', 'items.product']));
    }

    public function destroy(Sale $sale)
    {
        DB::beginTransaction();

        try {
            foreach ($sale->items as $item) {
                // Record stock movement for cancellation
                StockMovement::record(
                    $item->product_id,
                    $sale->warehouse_id,
                    $item->quantity,
                    StockMovement::TYPE_SALE_RETURN,
                    $sale->reference . '-CANCEL',
                    $sale,
                    $item->unit_price,
                    'إلغاء مبيعات'
                );
            }

            if ($sale->client_id) {
                $sale->client->updateBalance($sale->grand_total, 'subtract');
            }

            $sale->delete();

            DB::commit();

            return response()->json(['message' => 'تم حذف المبيعات بنجاح']);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['message' => 'حدث خطأ أثناء الحذف'], 500);
        }
    }

    public function createReturn(Request $request, Sale $sale)
    {
        $request->validate([
            'items' => 'required|array|min:1',
            'items.*.product_id' => 'required|exists:products,id',
            'items.*.quantity' => 'required|numeric|min:0.01',
            'items.*.reason' => 'nullable|string',
            'note' => 'nullable|string',
        ]);

        DB::beginTransaction();

        try {
            $return = SaleReturn::create([
                'sale_id' => $sale->id,
                'client_id' => $sale->client_id,
                'warehouse_id' => $sale->warehouse_id,
                'user_id' => auth()->id(),
                'date' => now(),
                'note' => $request->note,
                'status' => 'approved',
            ]);

            foreach ($request->items as $item) {
                $saleItem = $sale->items()->where('product_id', $item['product_id'])->first();
                if (!$saleItem) {
                    throw new \Exception('المنتج غير موجود في المبيعات');
                }

                SaleReturnItem::create([
                    'sale_return_id' => $return->id,
                    'product_id' => $item['product_id'],
                    'quantity' => $item['quantity'],
                    'unit_price' => $saleItem->unit_price,
                    'reason' => $item['reason'] ?? null,
                ]);

                // Record stock movement
                StockMovement::record(
                    $item['product_id'],
                    $sale->warehouse_id,
                    $item['quantity'],
                    StockMovement::TYPE_SALE_RETURN,
                    $return->reference,
                    $return,
                    $saleItem->unit_price,
                    $item['reason'] ?? null
                );
            }

            $return->calculateTotals();

            if ($sale->client_id) {
                $sale->client->updateBalance($return->total_amount, 'subtract');
            }

            DB::commit();

            return response()->json($return->load(['client', 'items.product']), 201);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['message' => $e->getMessage()], 500);
        }
    }
}
