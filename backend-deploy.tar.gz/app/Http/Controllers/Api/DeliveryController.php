<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Delivery;
use App\Models\DeliveryOrder;
use App\Models\DeliveryReturn;
use App\Models\DeliveryStock;
use App\Models\Order;
use App\Models\Stock;
use App\Models\StockMovement;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DeliveryController extends Controller
{
    public function index(Request $request)
    {
        $query = Delivery::with(['livreur', 'vehicle']);

        if ($request->livreur_id) {
            $query->where('livreur_id', $request->livreur_id);
        }

        if ($request->status) {
            $query->where('status', $request->status);
        }

        if ($request->from_date) {
            $query->whereDate('date', '>=', $request->from_date);
        }

        if ($request->to_date) {
            $query->whereDate('date', '<=', $request->to_date);
        }

        $deliveries = $query->latest()->paginate($request->per_page ?? 15);

        return response()->json($deliveries);
    }

    public function store(Request $request)
    {
        $request->validate([
            'livreur_id' => 'required|exists:users,id',
            'vehicle_id' => 'nullable|exists:vehicles,id',
            'date' => 'required|date',
            'order_ids' => 'required|array|min:1',
            'order_ids.*' => 'exists:orders,id',
            'notes' => 'nullable|string',
        ]);

        DB::beginTransaction();

        try {
            // Get warehouse from first order
            $firstOrder = Order::find($request->order_ids[0]);
            $warehouseId = $firstOrder->warehouse_id;

            $delivery = Delivery::create([
                'livreur_id' => $request->livreur_id,
                'vehicle_id' => $request->vehicle_id,
                'warehouse_id' => $warehouseId,
                'date' => $request->date,
                'notes' => $request->notes,
                'status' => 'preparing',
                'total_orders' => count($request->order_ids),
            ]);

            $productQuantities = [];
            $totalAmount = 0;

            foreach ($request->order_ids as $index => $orderId) {
                $order = Order::with('items')->find($orderId);

                if ($order->status !== 'confirmed') {
                    throw new \Exception('الطلب غير مؤكد: ' . $order->reference);
                }

                DeliveryOrder::create([
                    'delivery_id' => $delivery->id,
                    'order_id' => $orderId,
                    'client_id' => $order->client_id,
                    'delivery_order' => $index + 1,
                    'status' => 'pending',
                    'amount_due' => $order->grand_total,
                    'amount_collected' => 0,
                ]);

                $totalAmount += $order->grand_total;
                $order->assignToDelivery();

                foreach ($order->items as $item) {
                    $productId = $item->product_id;
                    if (!isset($productQuantities[$productId])) {
                        $productQuantities[$productId] = 0;
                    }
                    $productQuantities[$productId] += $item->quantity_confirmed;
                }
            }

            // Update total amount
            $delivery->total_amount = $totalAmount;
            $delivery->save();

            foreach ($productQuantities as $productId => $quantity) {
                DeliveryStock::create([
                    'delivery_id' => $delivery->id,
                    'product_id' => $productId,
                    'quantity_loaded' => $quantity,
                ]);
            }

            DB::commit();

            return response()->json($delivery->load(['livreur', 'vehicle', 'warehouse', 'deliveryOrders.order', 'stock.product']), 201);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['message' => $e->getMessage()], 500);
        }
    }

    public function show(Delivery $delivery)
    {
        return response()->json($delivery->load([
            'livreur',
            'vehicle',
            'deliveryOrders.order.items.product',
            'deliveryOrders.client',
            'stock.product',
            'returns.product'
        ]));
    }

    public function start(Delivery $delivery)
    {
        if ($delivery->status !== 'preparing') {
            return response()->json(['message' => 'التوصيل ليس في حالة تحضير'], 400);
        }

        DB::beginTransaction();

        try {
            // Validate stock availability for all products
            $stockErrors = [];
            foreach ($delivery->stock as $deliveryStock) {
                $stock = Stock::where('product_id', $deliveryStock->product_id)
                    ->where('warehouse_id', $delivery->warehouse_id)
                    ->first();

                $availableQty = $stock ? $stock->quantity : 0;
                $requiredQty = $deliveryStock->quantity_loaded;

                if ($availableQty < $requiredQty) {
                    $product = \App\Models\Product::find($deliveryStock->product_id);
                    $productName = $product ? $product->name : 'غير معروف';
                    $stockErrors[] = "{$productName}: المطلوب {$requiredQty}، المتوفر {$availableQty}";
                }
            }

            if (count($stockErrors) > 0) {
                return response()->json([
                    'message' => 'الكمية غير متوفرة في المخزون',
                    'errors' => $stockErrors
                ], 400);
            }

            // Deduct stock from warehouse (products go OUT with livreur)
            foreach ($delivery->stock as $deliveryStock) {
                StockMovement::record(
                    $deliveryStock->product_id,
                    $delivery->warehouse_id,
                    $deliveryStock->quantity_loaded,
                    StockMovement::TYPE_DELIVERY_OUT,
                    $delivery->reference,
                    $delivery,
                    null,
                    'خروج للتوصيل'
                );
            }

            $delivery->start();

            DB::commit();

            return response()->json($delivery->load(['stock.product']));
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['message' => $e->getMessage()], 500);
        }
    }

    public function complete(Delivery $delivery)
    {
        if ($delivery->status !== 'in_progress') {
            return response()->json(['message' => 'التوصيل ليس قيد التنفيذ'], 400);
        }

        $delivery->complete();

        return response()->json($delivery->load(['deliveryOrders', 'returns']));
    }

    public function deliverOrder(Request $request, Delivery $delivery, DeliveryOrder $deliveryOrder)
    {
        // Allow delivery for pending or postponed orders
        if (!in_array($deliveryOrder->status, ['pending', 'postponed'])) {
            return response()->json(['message' => 'حالة الطلب غير صالحة'], 400);
        }

        $request->validate([
            'amount_collected' => 'nullable|numeric|min:0',
        ]);

        DB::beginTransaction();

        try {
            $deliveryOrder->markDelivered();

            // Update money collected
            $deliveryOrder->amount_collected = $request->amount_collected ?? $deliveryOrder->amount_due;
            $deliveryOrder->save();

            // Track delivery in delivery_stock (stock already deducted when delivery started)
            foreach ($deliveryOrder->order->items as $item) {
                $deliveryStock = $delivery->stock()->where('product_id', $item->product_id)->first();
                if ($deliveryStock) {
                    $deliveryStock->recordDelivery($item->quantity_confirmed);
                }
            }

            $delivery->updateCounts();

            DB::commit();

            return response()->json($deliveryOrder->load('order'));
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['message' => $e->getMessage()], 500);
        }
    }

    public function partialDelivery(Request $request, Delivery $delivery, DeliveryOrder $deliveryOrder)
    {
        $request->validate([
            'items' => 'required|array|min:1',
            'items.*.product_id' => 'required|exists:products,id',
            'items.*.quantity_delivered' => 'required|numeric|min:0',
            'items.*.quantity_returned' => 'nullable|numeric|min:0',
            'items.*.return_reason' => 'nullable|in:refused,damaged,excess,store_closed,wrong,other',
            'amount_collected' => 'nullable|numeric|min:0',
        ]);

        DB::beginTransaction();

        try {
            $deliveryOrder->markPartial();

            // Update money collected
            if ($request->has('amount_collected')) {
                $deliveryOrder->amount_collected = $request->amount_collected;
                $deliveryOrder->save();
            }

            foreach ($request->items as $item) {
                $orderItem = $deliveryOrder->order->items()->where('product_id', $item['product_id'])->first();
                if ($orderItem) {
                    $orderItem->quantity_delivered = $item['quantity_delivered'];
                    $orderItem->save();

                    // Track delivery in delivery_stock (stock already deducted when delivery started)
                    $deliveryStock = $delivery->stock()->where('product_id', $item['product_id'])->first();
                    if ($deliveryStock) {
                        $deliveryStock->recordDelivery($item['quantity_delivered']);
                    }

                    if (isset($item['quantity_returned']) && $item['quantity_returned'] > 0) {
                        DeliveryReturn::create([
                            'delivery_id' => $delivery->id,
                            'order_id' => $deliveryOrder->order_id,
                            'product_id' => $item['product_id'],
                            'quantity' => $item['quantity_returned'],
                            'reason' => $item['return_reason'] ?? 'other',
                        ]);

                        if ($deliveryStock) {
                            $deliveryStock->recordReturn($item['quantity_returned']);
                        }
                    }
                }
            }

            $delivery->updateCounts();

            DB::commit();

            return response()->json($deliveryOrder->load('order.items'));
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['message' => $e->getMessage()], 500);
        }
    }

    public function failOrder(Request $request, Delivery $delivery, DeliveryOrder $deliveryOrder)
    {
        $request->validate([
            'reason' => 'required|string',
        ]);

        $deliveryOrder->markFailed($request->reason);
        $delivery->updateCounts();

        foreach ($deliveryOrder->order->items as $item) {
            DeliveryReturn::create([
                'delivery_id' => $delivery->id,
                'order_id' => $deliveryOrder->order_id,
                'product_id' => $item->product_id,
                'quantity' => $item->quantity_confirmed,
                'reason' => 'store_closed',
                'notes' => $request->reason,
            ]);

            $deliveryStock = $delivery->stock()->where('product_id', $item->product_id)->first();
            if ($deliveryStock) {
                $deliveryStock->recordReturn($item->quantity_confirmed);
            }
        }

        return response()->json($deliveryOrder);
    }

    public function postponeOrder(Request $request, Delivery $delivery, DeliveryOrder $deliveryOrder)
    {
        $request->validate([
            'notes' => 'nullable|string',
        ]);

        $deliveryOrder->postpone($request->notes);
        $delivery->updateCounts();

        return response()->json($deliveryOrder);
    }

    public function processReturns(Request $request, Delivery $delivery)
    {
        $request->validate([
            'warehouse_id' => 'required|exists:warehouses,id',
        ]);

        $returns = $delivery->returns()->unprocessed()->get();

        foreach ($returns as $return) {
            $return->process($request->warehouse_id);
        }

        return response()->json(['message' => 'تمت معالجة المرتجعات بنجاح', 'count' => $returns->count()]);
    }

    public function getMyActiveDelivery(Request $request)
    {
        $delivery = Delivery::where('livreur_id', auth()->id())
            ->whereIn('status', ['preparing', 'in_progress'])
            ->with(['deliveryOrders.order.items.product', 'deliveryOrders.client', 'stock.product'])
            ->first();

        return response()->json($delivery);
    }

    public function getMyDeliveries(Request $request)
    {
        $deliveries = Delivery::where('livreur_id', auth()->id())
            ->with(['deliveryOrders', 'returns'])
            ->latest()
            ->paginate($request->per_page ?? 15);

        return response()->json($deliveries);
    }

    public function getDeliveryOrderItems(Delivery $delivery, DeliveryOrder $deliveryOrder)
    {
        // Load the order with its items and product details
        $deliveryOrder->load(['order.items.product', 'client']);

        return response()->json([
            'delivery_order' => $deliveryOrder,
            'items' => $deliveryOrder->order->items->map(function ($item) {
                return [
                    'id' => $item->id,
                    'order_id' => $item->order_id,
                    'product_id' => $item->product_id,
                    'product_name' => $item->product->name ?? null,
                    'quantity_ordered' => $item->quantity_ordered,
                    'quantity_confirmed' => $item->quantity_confirmed,
                    'quantity_delivered' => $item->quantity_delivered,
                    'quantity_returned' => $item->quantity_returned,
                    'unit_price' => $item->unit_price,
                    'discount' => $item->discount,
                    'subtotal' => $item->subtotal,
                    'notes' => $item->notes,
                ];
            }),
        ]);
    }
}
