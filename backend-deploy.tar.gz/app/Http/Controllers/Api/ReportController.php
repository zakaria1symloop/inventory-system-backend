<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Delivery;
use App\Models\DeliveryOrder;
use App\Models\Stock;
use App\Models\StockMovement;
use App\Models\Product;
use App\Models\Client;
use App\Models\User;
use App\Models\Payment;
use App\Models\Sale;
use App\Models\Purchase;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class ReportController extends Controller
{
    // ===================== SALES REPORTS =====================

    /**
     * Sales Summary Report
     */
    public function salesSummary(Request $request)
    {
        $fromDate = $request->from_date ? Carbon::parse($request->from_date)->startOfDay() : Carbon::now()->startOfMonth();
        $toDate = $request->to_date ? Carbon::parse($request->to_date)->endOfDay() : Carbon::now()->endOfDay();

        // Orders summary
        $orderStats = Order::whereBetween('created_at', [$fromDate, $toDate])
            ->selectRaw('
                COUNT(*) as total_orders,
                SUM(CASE WHEN status = "delivered" THEN 1 ELSE 0 END) as delivered_orders,
                SUM(CASE WHEN status = "cancelled" THEN 1 ELSE 0 END) as cancelled_orders,
                SUM(CASE WHEN status = "pending" THEN 1 ELSE 0 END) as pending_orders,
                SUM(CASE WHEN status = "delivered" THEN grand_total ELSE 0 END) as total_revenue,
                SUM(grand_total) as total_value
            ')
            ->first();

        // Sales by day
        $salesByDay = Order::whereBetween('created_at', [$fromDate, $toDate])
            ->where('status', 'delivered')
            ->selectRaw('DATE(created_at) as date, COUNT(*) as orders, SUM(grand_total) as revenue')
            ->groupByRaw('DATE(created_at)')
            ->orderByRaw('DATE(created_at)')
            ->get();

        // Top products
        $topProducts = OrderItem::join('orders', 'order_items.order_id', '=', 'orders.id')
            ->join('products', 'order_items.product_id', '=', 'products.id')
            ->whereBetween('orders.created_at', [$fromDate, $toDate])
            ->where('orders.status', 'delivered')
            ->selectRaw('
                products.id,
                products.name,
                products.barcode,
                SUM(order_items.quantity_delivered) as total_quantity,
                SUM(order_items.subtotal) as total_revenue
            ')
            ->groupBy('products.id', 'products.name', 'products.barcode')
            ->orderByDesc('total_revenue')
            ->limit(10)
            ->get();

        // Top clients
        $topClients = Order::join('clients', 'orders.client_id', '=', 'clients.id')
            ->whereBetween('orders.created_at', [$fromDate, $toDate])
            ->where('orders.status', 'delivered')
            ->selectRaw('
                clients.id,
                clients.name,
                clients.phone,
                COUNT(*) as total_orders,
                SUM(orders.grand_total) as total_revenue
            ')
            ->groupBy('clients.id', 'clients.name', 'clients.phone')
            ->orderByDesc('total_revenue')
            ->limit(10)
            ->get();

        return response()->json([
            'period' => [
                'from' => $fromDate->format('Y-m-d'),
                'to' => $toDate->format('Y-m-d'),
            ],
            'summary' => $orderStats,
            'sales_by_day' => $salesByDay,
            'top_products' => $topProducts,
            'top_clients' => $topClients,
        ]);
    }

    /**
     * Detailed Sales Report - By Product
     */
    public function salesByProduct(Request $request)
    {
        $fromDate = $request->from_date ? Carbon::parse($request->from_date)->startOfDay() : Carbon::now()->startOfMonth();
        $toDate = $request->to_date ? Carbon::parse($request->to_date)->endOfDay() : Carbon::now()->endOfDay();

        $query = OrderItem::join('orders', 'order_items.order_id', '=', 'orders.id')
            ->join('products', 'order_items.product_id', '=', 'products.id')
            ->leftJoin('categories', 'products.category_id', '=', 'categories.id')
            ->whereBetween('orders.created_at', [$fromDate, $toDate])
            ->where('orders.status', 'delivered');

        if ($request->category_id) {
            $query->where('products.category_id', $request->category_id);
        }

        $data = $query->selectRaw('
                products.id,
                products.name,
                products.barcode,
                categories.name as category_name,
                products.retail_price,
                products.cost_price,
                SUM(order_items.quantity_delivered) as total_quantity,
                SUM(order_items.subtotal) as total_revenue,
                SUM(order_items.quantity_delivered * products.cost_price) as total_cost,
                SUM(order_items.subtotal) - SUM(order_items.quantity_delivered * products.cost_price) as profit
            ')
            ->groupBy('products.id', 'products.name', 'products.barcode', 'categories.name', 'products.retail_price', 'products.cost_price')
            ->orderByDesc('total_revenue')
            ->get();

        $totals = [
            'total_quantity' => $data->sum('total_quantity'),
            'total_revenue' => $data->sum('total_revenue'),
            'total_cost' => $data->sum('total_cost'),
            'total_profit' => $data->sum('profit'),
        ];

        return response()->json([
            'period' => [
                'from' => $fromDate->format('Y-m-d'),
                'to' => $toDate->format('Y-m-d'),
            ],
            'data' => $data,
            'totals' => $totals,
        ]);
    }

    /**
     * Detailed Sales Report - By Client
     */
    public function salesByClient(Request $request)
    {
        $fromDate = $request->from_date ? Carbon::parse($request->from_date)->startOfDay() : Carbon::now()->startOfMonth();
        $toDate = $request->to_date ? Carbon::parse($request->to_date)->endOfDay() : Carbon::now()->endOfDay();

        $data = Order::join('clients', 'orders.client_id', '=', 'clients.id')
            ->whereBetween('orders.created_at', [$fromDate, $toDate])
            ->where('orders.status', 'delivered')
            ->selectRaw('
                clients.id,
                clients.name,
                clients.phone,
                clients.address,
                COUNT(*) as total_orders,
                SUM(orders.grand_total) as total_revenue,
                AVG(orders.grand_total) as avg_order_value,
                MIN(orders.created_at) as first_order,
                MAX(orders.created_at) as last_order
            ')
            ->groupBy('clients.id', 'clients.name', 'clients.phone', 'clients.address')
            ->orderByDesc('total_revenue')
            ->get();

        $totals = [
            'total_clients' => $data->count(),
            'total_orders' => $data->sum('total_orders'),
            'total_revenue' => $data->sum('total_revenue'),
        ];

        return response()->json([
            'period' => [
                'from' => $fromDate->format('Y-m-d'),
                'to' => $toDate->format('Y-m-d'),
            ],
            'data' => $data,
            'totals' => $totals,
        ]);
    }

    /**
     * Detailed Sales Report - By Seller
     */
    public function salesBySeller(Request $request)
    {
        $fromDate = $request->from_date ? Carbon::parse($request->from_date)->startOfDay() : Carbon::now()->startOfMonth();
        $toDate = $request->to_date ? Carbon::parse($request->to_date)->endOfDay() : Carbon::now()->endOfDay();

        $data = Order::join('users', 'orders.seller_id', '=', 'users.id')
            ->whereBetween('orders.created_at', [$fromDate, $toDate])
            ->selectRaw('
                users.id,
                users.name,
                COUNT(*) as total_orders,
                SUM(CASE WHEN orders.status = "delivered" THEN 1 ELSE 0 END) as delivered_orders,
                SUM(CASE WHEN orders.status = "cancelled" THEN 1 ELSE 0 END) as cancelled_orders,
                SUM(CASE WHEN orders.status = "delivered" THEN orders.grand_total ELSE 0 END) as total_revenue,
                AVG(CASE WHEN orders.status = "delivered" THEN orders.grand_total ELSE NULL END) as avg_order_value
            ')
            ->groupBy('users.id', 'users.name')
            ->orderByDesc('total_revenue')
            ->get();

        return response()->json([
            'period' => [
                'from' => $fromDate->format('Y-m-d'),
                'to' => $toDate->format('Y-m-d'),
            ],
            'data' => $data,
        ]);
    }

    // ===================== DELIVERY REPORTS =====================

    /**
     * Delivery Summary Report
     */
    public function deliverySummary(Request $request)
    {
        $fromDate = $request->from_date ? Carbon::parse($request->from_date)->startOfDay() : Carbon::now()->startOfMonth();
        $toDate = $request->to_date ? Carbon::parse($request->to_date)->endOfDay() : Carbon::now()->endOfDay();

        $summary = Delivery::whereBetween('date', [$fromDate, $toDate])
            ->selectRaw('
                COUNT(*) as total_deliveries,
                SUM(CASE WHEN status = "completed" THEN 1 ELSE 0 END) as completed_deliveries,
                SUM(CASE WHEN status = "in_progress" THEN 1 ELSE 0 END) as in_progress_deliveries,
                SUM(total_orders) as total_orders,
                SUM(delivered_count) as delivered_orders,
                SUM(failed_count) as failed_orders,
                SUM(total_amount) as total_amount,
                SUM(collected_amount) as collected_amount
            ')
            ->first();

        // Calculate success rate
        $successRate = $summary->total_orders > 0
            ? round(($summary->delivered_orders / $summary->total_orders) * 100, 2)
            : 0;

        // By day
        $byDay = Delivery::whereBetween('date', [$fromDate, $toDate])
            ->selectRaw('
                date,
                COUNT(*) as deliveries,
                SUM(delivered_count) as delivered,
                SUM(failed_count) as failed,
                SUM(collected_amount) as collected
            ')
            ->groupBy('date')
            ->orderBy('date')
            ->get();

        return response()->json([
            'period' => [
                'from' => $fromDate->format('Y-m-d'),
                'to' => $toDate->format('Y-m-d'),
            ],
            'summary' => array_merge($summary->toArray(), ['success_rate' => $successRate]),
            'by_day' => $byDay,
        ]);
    }

    /**
     * Delivery Report - By Livreur
     */
    public function deliveryByLivreur(Request $request)
    {
        $fromDate = $request->from_date ? Carbon::parse($request->from_date)->startOfDay() : Carbon::now()->startOfMonth();
        $toDate = $request->to_date ? Carbon::parse($request->to_date)->endOfDay() : Carbon::now()->endOfDay();

        $data = Delivery::join('users', 'deliveries.livreur_id', '=', 'users.id')
            ->whereBetween('deliveries.date', [$fromDate, $toDate])
            ->selectRaw('
                users.id,
                users.name,
                COUNT(*) as total_deliveries,
                SUM(deliveries.total_orders) as total_orders,
                SUM(deliveries.delivered_count) as delivered_orders,
                SUM(deliveries.failed_count) as failed_orders,
                SUM(deliveries.total_amount) as total_amount,
                SUM(deliveries.collected_amount) as collected_amount,
                ROUND((SUM(deliveries.delivered_count) / NULLIF(SUM(deliveries.total_orders), 0)) * 100, 2) as success_rate
            ')
            ->groupBy('users.id', 'users.name')
            ->orderByDesc('delivered_orders')
            ->get();

        return response()->json([
            'period' => [
                'from' => $fromDate->format('Y-m-d'),
                'to' => $toDate->format('Y-m-d'),
            ],
            'data' => $data,
        ]);
    }

    /**
     * Delivery Details - Individual deliveries
     */
    public function deliveryDetails(Request $request)
    {
        $fromDate = $request->from_date ? Carbon::parse($request->from_date)->startOfDay() : Carbon::now()->startOfMonth();
        $toDate = $request->to_date ? Carbon::parse($request->to_date)->endOfDay() : Carbon::now()->endOfDay();

        $query = Delivery::with(['livreur', 'vehicle'])
            ->whereBetween('date', [$fromDate, $toDate]);

        if ($request->livreur_id) {
            $query->where('livreur_id', $request->livreur_id);
        }

        if ($request->status) {
            $query->where('status', $request->status);
        }

        $data = $query->orderByDesc('date')
            ->get()
            ->map(function ($delivery) {
                return [
                    'id' => $delivery->id,
                    'reference' => $delivery->reference,
                    'date' => $delivery->date,
                    'livreur_name' => $delivery->livreur->name ?? 'N/A',
                    'vehicle' => $delivery->vehicle->name ?? 'N/A',
                    'status' => $delivery->status,
                    'total_orders' => $delivery->total_orders,
                    'delivered_count' => $delivery->delivered_count,
                    'failed_count' => $delivery->failed_count,
                    'success_rate' => $delivery->total_orders > 0
                        ? round(($delivery->delivered_count / $delivery->total_orders) * 100, 2)
                        : 0,
                    'total_amount' => $delivery->total_amount,
                    'collected_amount' => $delivery->collected_amount,
                    'start_time' => $delivery->start_time,
                    'end_time' => $delivery->end_time,
                ];
            });

        return response()->json([
            'period' => [
                'from' => $fromDate->format('Y-m-d'),
                'to' => $toDate->format('Y-m-d'),
            ],
            'data' => $data,
        ]);
    }

    // ===================== STOCK REPORTS =====================

    /**
     * Stock Summary Report
     */
    public function stockSummary(Request $request)
    {
        $query = Stock::join('products', 'stocks.product_id', '=', 'products.id')
            ->join('warehouses', 'stocks.warehouse_id', '=', 'warehouses.id')
            ->leftJoin('categories', 'products.category_id', '=', 'categories.id');

        if ($request->warehouse_id) {
            $query->where('stocks.warehouse_id', $request->warehouse_id);
        }

        if ($request->category_id) {
            $query->where('products.category_id', $request->category_id);
        }

        $data = $query->selectRaw('
                products.id,
                products.name,
                products.barcode,
                categories.name as category_name,
                warehouses.name as warehouse_name,
                stocks.quantity,
                products.stock_alert as min_stock,
                products.retail_price,
                products.cost_price,
                stocks.quantity * products.cost_price as stock_value,
                CASE WHEN stocks.quantity <= products.stock_alert THEN 1 ELSE 0 END as is_low_stock
            ')
            ->orderBy('products.name')
            ->get();

        $totals = [
            'total_products' => $data->count(),
            'total_quantity' => $data->sum('quantity'),
            'total_value' => $data->sum('stock_value'),
            'low_stock_count' => $data->where('is_low_stock', 1)->count(),
        ];

        return response()->json([
            'data' => $data,
            'totals' => $totals,
        ]);
    }

    /**
     * Stock Movements Report
     */
    public function stockMovements(Request $request)
    {
        $fromDate = $request->from_date ? Carbon::parse($request->from_date)->startOfDay() : Carbon::now()->startOfMonth();
        $toDate = $request->to_date ? Carbon::parse($request->to_date)->endOfDay() : Carbon::now()->endOfDay();

        $query = StockMovement::with(['product', 'warehouse'])
            ->whereBetween('created_at', [$fromDate, $toDate]);

        if ($request->warehouse_id) {
            $query->where('warehouse_id', $request->warehouse_id);
        }

        if ($request->product_id) {
            $query->where('product_id', $request->product_id);
        }

        if ($request->type) {
            $query->where('type', $request->type);
        }

        $data = $query->orderByDesc('created_at')
            ->get()
            ->map(function ($movement) {
                return [
                    'id' => $movement->id,
                    'date' => $movement->created_at->format('Y-m-d H:i'),
                    'product_name' => $movement->product->name ?? 'N/A',
                    'product_barcode' => $movement->product->barcode ?? 'N/A',
                    'warehouse_name' => $movement->warehouse->name ?? 'N/A',
                    'type' => $movement->type,
                    'type_label' => $this->getMovementTypeLabel($movement->type),
                    'quantity' => $movement->quantity,
                    'before_quantity' => $movement->before_quantity,
                    'after_quantity' => $movement->after_quantity,
                    'reference' => $movement->reference,
                    'notes' => $movement->notes,
                ];
            });

        // Summary by type
        $summary = StockMovement::whereBetween('created_at', [$fromDate, $toDate])
            ->selectRaw('type, SUM(quantity) as total_quantity, COUNT(*) as count')
            ->groupBy('type')
            ->get();

        return response()->json([
            'period' => [
                'from' => $fromDate->format('Y-m-d'),
                'to' => $toDate->format('Y-m-d'),
            ],
            'data' => $data,
            'summary' => $summary,
        ]);
    }

    /**
     * Low Stock Alert Report
     */
    public function lowStockAlert(Request $request)
    {
        $query = Stock::join('products', 'stocks.product_id', '=', 'products.id')
            ->join('warehouses', 'stocks.warehouse_id', '=', 'warehouses.id')
            ->leftJoin('categories', 'products.category_id', '=', 'categories.id')
            ->whereRaw('stocks.quantity <= products.stock_alert');

        if ($request->warehouse_id) {
            $query->where('stocks.warehouse_id', $request->warehouse_id);
        }

        $data = $query->selectRaw('
                products.id,
                products.name,
                products.barcode,
                categories.name as category_name,
                warehouses.name as warehouse_name,
                stocks.quantity as current_stock,
                products.stock_alert as min_stock,
                products.stock_alert - stocks.quantity as shortage
            ')
            ->orderByDesc('shortage')
            ->get();

        return response()->json([
            'data' => $data,
            'total_alerts' => $data->count(),
        ]);
    }

    // ===================== FINANCIAL REPORTS =====================

    /**
     * Financial Summary Report
     */
    public function financialSummary(Request $request)
    {
        $fromDate = $request->from_date ? Carbon::parse($request->from_date)->startOfDay() : Carbon::now()->startOfMonth();
        $toDate = $request->to_date ? Carbon::parse($request->to_date)->endOfDay() : Carbon::now()->endOfDay();

        // Sales revenue
        $salesRevenue = Order::whereBetween('created_at', [$fromDate, $toDate])
            ->where('status', 'delivered')
            ->sum('grand_total');

        // Purchase costs
        $purchaseCosts = Purchase::whereBetween('created_at', [$fromDate, $toDate])
            ->where('status', 'received')
            ->sum('grand_total');

        // Collections from deliveries
        $collections = Delivery::whereBetween('date', [$fromDate, $toDate])
            ->sum('collected_amount');

        // Payments received
        $paymentsReceived = Payment::whereBetween('created_at', [$fromDate, $toDate])
            ->where('payable_type', 'App\\Models\\Sale')
            ->sum('amount');

        // Payments made
        $paymentsMade = Payment::whereBetween('created_at', [$fromDate, $toDate])
            ->where('payable_type', 'App\\Models\\Purchase')
            ->sum('amount');

        // Outstanding from clients
        $clientsOutstanding = Client::sum('balance');

        // Outstanding to suppliers
        $suppliersOutstanding = DB::table('suppliers')->sum('balance');

        return response()->json([
            'period' => [
                'from' => $fromDate->format('Y-m-d'),
                'to' => $toDate->format('Y-m-d'),
            ],
            'summary' => [
                'sales_revenue' => $salesRevenue,
                'purchase_costs' => $purchaseCosts,
                'gross_profit' => $salesRevenue - $purchaseCosts,
                'collections' => $collections,
                'payments_received' => $paymentsReceived,
                'payments_made' => $paymentsMade,
                'net_cash_flow' => $collections + $paymentsReceived - $paymentsMade,
            ],
            'outstanding' => [
                'clients_receivable' => $clientsOutstanding,
                'suppliers_payable' => $suppliersOutstanding,
            ],
        ]);
    }

    /**
     * Client Balances Report
     */
    public function clientBalances(Request $request)
    {
        $data = Client::selectRaw('
                id,
                name,
                phone,
                address,
                balance,
                credit_limit,
                CASE WHEN balance > credit_limit THEN 1 ELSE 0 END as over_limit
            ')
            ->orderByDesc('balance')
            ->get();

        $totals = [
            'total_clients' => $data->count(),
            'total_balance' => $data->sum('balance'),
            'over_limit_count' => $data->where('over_limit', 1)->count(),
        ];

        return response()->json([
            'data' => $data,
            'totals' => $totals,
        ]);
    }

    /**
     * Collections Report - By Date
     */
    public function collectionsReport(Request $request)
    {
        $fromDate = $request->from_date ? Carbon::parse($request->from_date)->startOfDay() : Carbon::now()->startOfMonth();
        $toDate = $request->to_date ? Carbon::parse($request->to_date)->endOfDay() : Carbon::now()->endOfDay();

        // From deliveries
        $deliveryCollections = Delivery::with('livreur')
            ->whereBetween('date', [$fromDate, $toDate])
            ->where('collected_amount', '>', 0)
            ->get()
            ->map(function ($delivery) {
                return [
                    'date' => $delivery->date,
                    'type' => 'delivery',
                    'reference' => $delivery->reference,
                    'livreur' => $delivery->livreur->name ?? 'N/A',
                    'amount' => $delivery->collected_amount,
                    'expected' => $delivery->total_amount,
                ];
            });

        // Summary by livreur
        $byLivreur = Delivery::join('users', 'deliveries.livreur_id', '=', 'users.id')
            ->whereBetween('deliveries.date', [$fromDate, $toDate])
            ->selectRaw('
                users.id,
                users.name,
                SUM(deliveries.total_amount) as expected,
                SUM(deliveries.collected_amount) as collected,
                SUM(deliveries.total_amount) - SUM(deliveries.collected_amount) as pending
            ')
            ->groupBy('users.id', 'users.name')
            ->get();

        return response()->json([
            'period' => [
                'from' => $fromDate->format('Y-m-d'),
                'to' => $toDate->format('Y-m-d'),
            ],
            'collections' => $deliveryCollections,
            'by_livreur' => $byLivreur,
            'totals' => [
                'expected' => $byLivreur->sum('expected'),
                'collected' => $byLivreur->sum('collected'),
                'pending' => $byLivreur->sum('pending'),
            ],
        ]);
    }

    // ===================== HELPER METHODS =====================

    private function getMovementTypeLabel($type)
    {
        $labels = [
            'purchase' => 'شراء',
            'sale' => 'بيع',
            'adjustment_add' => 'تعديل إضافة',
            'adjustment_sub' => 'تعديل نقص',
            'transfer_in' => 'تحويل وارد',
            'transfer_out' => 'تحويل صادر',
            'delivery_out' => 'خروج للتوصيل',
            'delivery_return' => 'مرتجع من التوصيل',
            'initial' => 'رصيد افتتاحي',
        ];

        return $labels[$type] ?? $type;
    }
}
