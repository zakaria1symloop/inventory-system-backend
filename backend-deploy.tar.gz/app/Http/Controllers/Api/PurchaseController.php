<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Purchase;
use App\Models\PurchaseItem;
use App\Models\PurchaseReturn;
use App\Models\PurchaseReturnItem;
use App\Models\Stock;
use App\Models\StockMovement;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PurchaseController extends Controller
{
    public function index(Request $request)
    {
        $query = Purchase::with(['supplier', 'warehouse', 'user']);

        if ($request->supplier_id) {
            $query->where('supplier_id', $request->supplier_id);
        }

        if ($request->warehouse_id) {
            $query->where('warehouse_id', $request->warehouse_id);
        }

        if ($request->status) {
            $query->where('status', $request->status);
        }

        if ($request->payment_status) {
            $query->where('payment_status', $request->payment_status);
        }

        if ($request->from_date) {
            $query->whereDate('date', '>=', $request->from_date);
        }

        if ($request->to_date) {
            $query->whereDate('date', '<=', $request->to_date);
        }

        if ($request->search) {
            $query->where('reference', 'like', "%{$request->search}%");
        }

        $purchases = $query->latest()->paginate($request->per_page ?? 15);

        return response()->json($purchases);
    }

    public function store(Request $request)
    {
        $request->validate([
            'supplier_id' => 'nullable|exists:suppliers,id',
            'warehouse_id' => 'required|exists:warehouses,id',
            'date' => 'required|date',
            'discount' => 'nullable|numeric|min:0',
            'tax' => 'nullable|numeric|min:0',
            'shipping' => 'nullable|numeric|min:0',
            'note' => 'nullable|string',
            'items' => 'required|array|min:1',
            'items.*.product_id' => 'required|exists:products,id',
            'items.*.quantity' => 'required|numeric|min:0.01',
            'items.*.unit_price' => 'required|numeric|min:0',
            'items.*.discount' => 'nullable|numeric|min:0',
            'items.*.tax' => 'nullable|numeric|min:0',
        ]);

        DB::beginTransaction();

        try {
            $purchase = Purchase::create([
                'supplier_id' => $request->supplier_id,
                'warehouse_id' => $request->warehouse_id,
                'user_id' => auth()->id(),
                'date' => $request->date,
                'discount' => $request->discount ?? 0,
                'tax' => $request->tax ?? 0,
                'shipping' => $request->shipping ?? 0,
                'note' => $request->note,
                'status' => 'received',
            ]);

            foreach ($request->items as $item) {
                PurchaseItem::create([
                    'purchase_id' => $purchase->id,
                    'product_id' => $item['product_id'],
                    'quantity' => $item['quantity'],
                    'unit_price' => $item['unit_price'],
                    'discount' => $item['discount'] ?? 0,
                    'tax' => $item['tax'] ?? 0,
                ]);

                // Record stock movement
                StockMovement::record(
                    $item['product_id'],
                    $request->warehouse_id,
                    $item['quantity'],
                    StockMovement::TYPE_PURCHASE,
                    $purchase->reference,
                    $purchase,
                    $item['unit_price']
                );
            }

            $purchase->calculateTotals();

            if ($request->supplier_id) {
                $purchase->supplier->updateBalance($purchase->grand_total, 'add');
            }

            DB::commit();

            return response()->json($purchase->load(['supplier', 'warehouse', 'user', 'items.product']), 201);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['message' => 'حدث خطأ أثناء إنشاء المشتريات', 'error' => $e->getMessage()], 500);
        }
    }

    public function show(Purchase $purchase)
    {
        return response()->json($purchase->load(['supplier', 'warehouse', 'user', 'items.product', 'payments', 'returns']));
    }

    public function update(Request $request, Purchase $purchase)
    {
        $request->validate([
            'discount' => 'nullable|numeric|min:0',
            'tax' => 'nullable|numeric|min:0',
            'shipping' => 'nullable|numeric|min:0',
            'note' => 'nullable|string',
        ]);

        $purchase->update($request->only(['discount', 'tax', 'shipping', 'note']));
        $purchase->calculateTotals();

        return response()->json($purchase->load(['supplier', 'warehouse', 'user', 'items.product']));
    }

    public function destroy(Purchase $purchase)
    {
        DB::beginTransaction();

        try {
            foreach ($purchase->items as $item) {
                // Record stock movement for cancellation
                StockMovement::record(
                    $item->product_id,
                    $purchase->warehouse_id,
                    $item->quantity,
                    StockMovement::TYPE_PURCHASE_RETURN,
                    $purchase->reference . '-CANCEL',
                    $purchase,
                    $item->unit_price,
                    'إلغاء مشتريات'
                );
            }

            if ($purchase->supplier_id) {
                $purchase->supplier->updateBalance($purchase->grand_total, 'subtract');
            }

            $purchase->delete();

            DB::commit();

            return response()->json(['message' => 'تم حذف المشتريات بنجاح']);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['message' => 'حدث خطأ أثناء الحذف'], 500);
        }
    }

    public function createReturn(Request $request, Purchase $purchase)
    {
        $request->validate([
            'items' => 'required|array|min:1',
            'items.*.product_id' => 'required|exists:products,id',
            'items.*.quantity' => 'required|numeric|min:0.01',
            'items.*.reason' => 'nullable|string',
            'note' => 'nullable|string',
        ]);

        DB::beginTransaction();

        try {
            $return = PurchaseReturn::create([
                'purchase_id' => $purchase->id,
                'supplier_id' => $purchase->supplier_id,
                'warehouse_id' => $purchase->warehouse_id,
                'user_id' => auth()->id(),
                'date' => now(),
                'note' => $request->note,
                'status' => 'approved',
            ]);

            foreach ($request->items as $item) {
                $purchaseItem = $purchase->items()->where('product_id', $item['product_id'])->first();
                if (!$purchaseItem) {
                    throw new \Exception('المنتج غير موجود في المشتريات');
                }

                PurchaseReturnItem::create([
                    'purchase_return_id' => $return->id,
                    'product_id' => $item['product_id'],
                    'quantity' => $item['quantity'],
                    'unit_price' => $purchaseItem->unit_price,
                    'reason' => $item['reason'] ?? null,
                ]);

                // Record stock movement
                StockMovement::record(
                    $item['product_id'],
                    $purchase->warehouse_id,
                    $item['quantity'],
                    StockMovement::TYPE_PURCHASE_RETURN,
                    $return->reference,
                    $return,
                    $purchaseItem->unit_price,
                    $item['reason'] ?? null
                );
            }

            $return->calculateTotals();

            if ($purchase->supplier_id) {
                $purchase->supplier->updateBalance($return->total_amount, 'subtract');
            }

            DB::commit();

            return response()->json($return->load(['supplier', 'items.product']), 201);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['message' => $e->getMessage()], 500);
        }
    }
}
